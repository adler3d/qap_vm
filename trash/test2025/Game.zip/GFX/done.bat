cd ..
run