rm asm2mashkod2016.h
rm mashkod.asm
rm qapcppout.asm